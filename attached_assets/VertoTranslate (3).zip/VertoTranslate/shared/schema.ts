import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const languages = pgTable("languages", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  nativeName: text("native_name").notNull(),
  flag: text("flag").notNull(),
  isOfflineAvailable: boolean("is_offline_available").default(false),
  sizeInMb: integer("size_in_mb"),
});

export const translations = pgTable("translations", {
  id: serial("id").primaryKey(),
  sourceText: text("source_text").notNull(),
  translatedText: text("translated_text").notNull(),
  sourceLanguage: text("source_language").notNull(),
  targetLanguage: text("target_language").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  isSaved: boolean("is_saved").default(false),
  userId: integer("user_id").references(() => users.id),
});

export const offlineLanguages = pgTable("offline_languages", {
  id: serial("id").primaryKey(),
  languageId: integer("language_id").references(() => languages.id),
  userId: integer("user_id").references(() => users.id),
  downloadedAt: timestamp("downloaded_at").defaultNow(),
});

export const insertLanguageSchema = createInsertSchema(languages).omit({
  id: true,
});

export const insertTranslationSchema = createInsertSchema(translations).omit({
  id: true,
  createdAt: true,
});

export const insertOfflineLanguageSchema = createInsertSchema(offlineLanguages).omit({
  id: true,
  downloadedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertLanguage = z.infer<typeof insertLanguageSchema>;
export type Language = typeof languages.$inferSelect;

export type InsertTranslation = z.infer<typeof insertTranslationSchema>;
export type Translation = typeof translations.$inferSelect;

export type InsertOfflineLanguage = z.infer<typeof insertOfflineLanguageSchema>;
export type OfflineLanguage = typeof offlineLanguages.$inferSelect;
