import { createContext, useContext, useState, ReactNode, useCallback } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';

interface TranslationContextType {
  sourceLanguage: string;
  targetLanguage: string;
  sourceText: string;
  translatedText: string;
  detectedLanguage: string | null;
  isTranslating: boolean;
  isDetecting: boolean;
  error: string | null;
  setSourceLanguage: (code: string) => void;
  setTargetLanguage: (code: string) => void;
  setSourceText: (text: string) => void;
  setTranslatedText: (text: string) => void;
  swapLanguages: () => void;
  translate: () => Promise<void>;
  detectLanguage: () => Promise<void>;
  saveTranslation: (id: number) => Promise<void>;
  unsaveTranslation: (id: number) => Promise<void>;
  resetTranslation: () => void;
}

const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

export function TranslationProvider({ children }: { children: ReactNode }) {
  const [sourceLanguage, setSourceLanguage] = useState('en');
  const [targetLanguage, setTargetLanguage] = useState('fr');
  const [sourceText, setSourceText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [detectedLanguage, setDetectedLanguage] = useState<string | null>(null);
  const [isTranslating, setIsTranslating] = useState(false);
  const [isDetecting, setIsDetecting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const swapLanguages = useCallback(() => {
    setSourceLanguage(targetLanguage);
    setTargetLanguage(sourceLanguage);
    setSourceText(translatedText);
    setTranslatedText(sourceText);
  }, [sourceLanguage, targetLanguage, sourceText, translatedText]);

  const translate = useCallback(async () => {
    if (!sourceText.trim()) {
      setError('Please enter text to translate');
      return;
    }
    
    setIsTranslating(true);
    setError(null);
    
    try {
      const response = await apiRequest('POST', '/api/translate', {
        text: sourceText.trim(),
        sourceLanguage,
        targetLanguage
      });
      
      const result = await response.json();
      // Check if we have translation in the response
      if (result.translatedText) {
        setTranslatedText(result.translatedText);
      } else if (result.translation && result.translation.translatedText) {
        setTranslatedText(result.translation.translatedText);
      } else {
        throw new Error('No translation returned from the server');
      }
      
      // Invalidate translations query to update history
      queryClient.invalidateQueries({ queryKey: ['/api/translations'] });
    } catch (err) {
      setError('Translation failed. Please try again.');
      console.error('Translation error:', err);
    } finally {
      setIsTranslating(false);
    }
  }, [sourceText, sourceLanguage, targetLanguage]);

  const detectLanguage = useCallback(async () => {
    if (!sourceText.trim()) {
      setError('Please enter text to detect language');
      return;
    }
    
    setIsDetecting(true);
    setError(null);
    
    try {
      const response = await apiRequest('POST', '/api/detect-language', {
        text: sourceText
      });
      
      const result = await response.json();
      setDetectedLanguage(result.detectedLanguage);
      setSourceLanguage(result.detectedLanguage);
    } catch (err) {
      setError('Language detection failed. Please try again.');
      console.error('Language detection error:', err);
    } finally {
      setIsDetecting(false);
    }
  }, [sourceText]);

  const saveTranslation = useCallback(async (id: number) => {
    try {
      await apiRequest('POST', `/api/translations/${id}/save`, {});
      queryClient.invalidateQueries({ queryKey: ['/api/translations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/translations/saved'] });
    } catch (err) {
      console.error('Error saving translation:', err);
      throw err;
    }
  }, []);

  const unsaveTranslation = useCallback(async (id: number) => {
    try {
      await apiRequest('POST', `/api/translations/${id}/unsave`, {});
      queryClient.invalidateQueries({ queryKey: ['/api/translations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/translations/saved'] });
    } catch (err) {
      console.error('Error unsaving translation:', err);
      throw err;
    }
  }, []);

  const resetTranslation = useCallback(() => {
    setSourceText('');
    setTranslatedText('');
    setError(null);
  }, []);

  return (
    <TranslationContext.Provider
      value={{
        sourceLanguage,
        targetLanguage,
        sourceText,
        translatedText,
        detectedLanguage,
        isTranslating,
        isDetecting,
        error,
        setSourceLanguage,
        setTargetLanguage,
        setSourceText,
        setTranslatedText,
        swapLanguages,
        translate,
        detectLanguage,
        saveTranslation,
        unsaveTranslation,
        resetTranslation
      }}
    >
      {children}
    </TranslationContext.Provider>
  );
}

export function useTranslation() {
  const context = useContext(TranslationContext);
  if (context === undefined) {
    throw new Error('useTranslation must be used within a TranslationProvider');
  }
  return context;
}
