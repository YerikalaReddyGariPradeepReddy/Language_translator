import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Language, OfflineLanguage } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

export default function OfflineLanguagesSection() {
  const { toast } = useToast();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);

  // Fetch offline languages
  const { 
    data: offlineLanguages = [], 
    isLoading: isLoadingOffline 
  } = useQuery<(OfflineLanguage & { language: Language })[]>({
    queryKey: ['/api/offline-languages'],
  });

  // Fetch all available languages for the dialog
  const { 
    data: allLanguages = [],
    isLoading: isLoadingLanguages
  } = useQuery<Language[]>({
    queryKey: ['/api/languages'],
  });

  // Add offline language mutation
  const addOfflineLanguageMutation = useMutation({
    mutationFn: async (languageId: number) => {
      const response = await apiRequest('POST', '/api/offline-languages', { languageId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/offline-languages'] });
      setIsAddDialogOpen(false);
      toast({
        title: "Success",
        description: "Language downloaded for offline use",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to download language",
        variant: "destructive"
      });
    }
  });

  // Remove offline language mutation
  const removeOfflineLanguageMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/offline-languages/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/offline-languages'] });
      toast({
        title: "Success",
        description: "Language removed from offline storage",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to remove language",
        variant: "destructive"
      });
    }
  });

  // Get available languages (those not already downloaded)
  const availableLanguages = allLanguages.filter(
    language => !offlineLanguages.some(ol => ol.language.id === language.id)
  );

  // Handle language download
  const handleDownloadLanguage = (languageId: number) => {
    addOfflineLanguageMutation.mutate(languageId);
  };

  // Handle language removal
  const handleRemoveLanguage = (id: number) => {
    removeOfflineLanguageMutation.mutate(id);
  };

  return (
    <div className="py-8 border-t border-zinc-200 dark:border-zinc-800">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold font-heading text-zinc-900 dark:text-white">
          Offline Languages
        </h2>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              Add language
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Download Language for Offline Use</DialogTitle>
              <DialogDescription>
                Select a language to download for offline translation
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 mt-4 max-h-[300px] overflow-y-auto">
              {isLoadingLanguages ? (
                <div className="flex justify-center items-center py-4">
                  <Loader2 className="h-6 w-6 animate-spin text-primary-500" />
                </div>
              ) : availableLanguages.length === 0 ? (
                <p className="text-center text-zinc-500 dark:text-zinc-400 py-4">
                  All languages have been downloaded
                </p>
              ) : (
                availableLanguages.map(language => (
                  <div 
                    key={language.id} 
                    className="flex items-center justify-between p-3 bg-zinc-50 dark:bg-zinc-800 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-700 transition-colors"
                  >
                    <div className="flex items-center">
                      <span className="text-2xl mr-3">{language.flag}</span>
                      <div>
                        <h4 className="font-medium text-zinc-900 dark:text-zinc-100">{language.name}</h4>
                        <p className="text-xs text-zinc-500 dark:text-zinc-400">{language.nativeName}</p>
                      </div>
                    </div>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => handleDownloadLanguage(language.id)}
                      disabled={addOfflineLanguageMutation.isPending}
                    >
                      {addOfflineLanguageMutation.isPending ? (
                        <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                      ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                        </svg>
                      )}
                      Download
                    </Button>
                  </div>
                ))
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {isLoadingOffline ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-800 p-4 animate-pulse">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-zinc-200 dark:bg-zinc-700 rounded-full mr-3"></div>
                <div className="flex-1">
                  <div className="h-4 bg-zinc-200 dark:bg-zinc-700 rounded w-24 mb-2"></div>
                  <div className="h-3 bg-zinc-200 dark:bg-zinc-700 rounded w-16"></div>
                </div>
                <div className="flex space-x-1">
                  <div className="w-7 h-7 bg-zinc-200 dark:bg-zinc-700 rounded"></div>
                  <div className="w-7 h-7 bg-zinc-200 dark:bg-zinc-700 rounded"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : offlineLanguages.length === 0 ? (
        <div className="text-center py-8 bg-zinc-50 dark:bg-zinc-800/50 rounded-lg border border-dashed border-zinc-300 dark:border-zinc-700">
          <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center mx-auto mb-3">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-600 dark:text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
          </div>
          <h3 className="font-medium text-zinc-900 dark:text-zinc-100 mb-1">No offline languages</h3>
          <p className="text-sm text-zinc-500 dark:text-zinc-400 mb-4 max-w-sm mx-auto">
            Download languages for offline use when traveling without reliable internet access
          </p>
          <Button 
            onClick={() => setIsAddDialogOpen(true)}
            variant="outline"
          >
            Add your first language
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {offlineLanguages.map(item => (
            <div key={item.id} className="bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-800 p-4 flex items-center justify-between">
              <div className="flex items-center">
                <span className="text-lg mr-3">{item.language.flag}</span>
                <div>
                  <h3 className="font-medium text-zinc-900 dark:text-white">{item.language.name}</h3>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400">
                    {item.language.sizeInMb}MB
                  </p>
                </div>
              </div>
              <div className="flex space-x-1">
                <button className="p-1 text-zinc-500 hover:text-zinc-700 dark:text-zinc-400 dark:hover:text-zinc-200">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 15v-1a4 4 0 00-4-4H8m0 0l3 3m-3-3l3-3m9 14V5a2 2 0 00-2-2H6a2 2 0 00-2 2v16l4-2 4 2 4-2 4 2z" />
                  </svg>
                </button>
                <button 
                  className="p-1 text-zinc-500 hover:text-zinc-700 dark:text-zinc-400 dark:hover:text-zinc-200"
                  onClick={() => handleRemoveLanguage(item.id)}
                  disabled={removeOfflineLanguageMutation.isPending}
                >
                  {removeOfflineLanguageMutation.isPending ? (
                    <Loader2 className="h-5 w-5 animate-spin" />
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  )}
                </button>
              </div>
            </div>
          ))}
          
          {/* Add new language card */}
          <div 
            className="bg-zinc-50 dark:bg-zinc-800/50 rounded-lg border border-dashed border-zinc-300 dark:border-zinc-700 p-4 flex items-center justify-center cursor-pointer hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
            onClick={() => setIsAddDialogOpen(true)}
          >
            <div className="text-center">
              <div className="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center mx-auto mb-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary-600 dark:text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                </svg>
              </div>
              <p className="text-sm font-medium text-zinc-700 dark:text-zinc-300">Add new language</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
