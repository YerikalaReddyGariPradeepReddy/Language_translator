import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Translation } from "@shared/schema";
import { formatDate, copyToClipboard } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "@/contexts/TranslationContext";

export default function RecentTranslationsSection() {
  const { toast } = useToast();
  const { saveTranslation } = useTranslation();
  
  const { data: translations = [], isLoading, error } = useQuery<Translation[]>({
    queryKey: ['/api/translations'],
    queryOptions: {
      select: (data) => data.slice(0, 3), // Show only recent 3 translations
    }
  });

  const handleCopyText = async (text: string) => {
    try {
      await copyToClipboard(text);
      toast({
        title: "Copied!",
        description: "Text copied to clipboard"
      });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy text",
        variant: "destructive"
      });
    }
  };

  const handleSaveTranslation = async (id: number) => {
    try {
      await saveTranslation(id);
      toast({
        title: "Saved!",
        description: "Translation saved successfully"
      });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to save translation",
        variant: "destructive"
      });
    }
  };

  if (isLoading) {
    return (
      <div className="py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold font-heading text-zinc-900 dark:text-white">
            Recent Translations
          </h2>
          <Link href="/history">
            <a className="text-primary-600 dark:text-primary-400 text-sm font-medium hover:underline">
              View all history
            </a>
          </Link>
        </div>
        
        <div className="space-y-4">
          {[1, 2].map((i) => (
            <div key={i} className="bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 p-4 animate-pulse">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <div className="h-4 w-24 bg-zinc-200 dark:bg-zinc-700 rounded"></div>
                  <div className="h-4 w-16 bg-zinc-200 dark:bg-zinc-700 rounded"></div>
                </div>
                <div className="flex space-x-2">
                  <div className="h-5 w-5 bg-zinc-200 dark:bg-zinc-700 rounded"></div>
                  <div className="h-5 w-5 bg-zinc-200 dark:bg-zinc-700 rounded"></div>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="h-6 w-full bg-zinc-200 dark:bg-zinc-700 rounded"></div>
                <div className="h-6 w-full bg-zinc-200 dark:bg-zinc-700 rounded"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold font-heading text-zinc-900 dark:text-white">
            Recent Translations
          </h2>
        </div>
        <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-lg border border-red-200 dark:border-red-800">
          <p className="text-red-600 dark:text-red-400">Failed to load recent translations. Please try again later.</p>
        </div>
      </div>
    );
  }

  if (translations.length === 0) {
    return (
      <div className="py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold font-heading text-zinc-900 dark:text-white">
            Recent Translations
          </h2>
        </div>
        <div className="bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 p-6 text-center">
          <p className="text-zinc-600 dark:text-zinc-400">No translations yet. Start translating to see your history here.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="py-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold font-heading text-zinc-900 dark:text-white">
          Recent Translations
        </h2>
        <Link href="/history">
          <a className="text-primary-600 dark:text-primary-400 text-sm font-medium hover:underline">
            View all history
          </a>
        </Link>
      </div>

      {translations.map((translation) => (
        <div key={translation.id} className="bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 p-4 mb-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium text-zinc-500 dark:text-zinc-400">
                {translation.sourceLanguage} → {translation.targetLanguage}
              </span>
              <span className="text-xs text-zinc-400 dark:text-zinc-500">
                {formatDate(translation.createdAt)}
              </span>
            </div>
            <div className="flex space-x-2">
              <button 
                className="text-zinc-400 dark:text-zinc-500 hover:text-zinc-600 dark:hover:text-zinc-300"
                onClick={() => handleCopyText(`${translation.sourceText}\n${translation.translatedText}`)}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
              </button>
              <button 
                className={`text-zinc-400 dark:text-zinc-500 hover:text-zinc-600 dark:hover:text-zinc-300 ${translation.isSaved ? 'text-primary-500 dark:text-primary-400' : ''}`}
                onClick={() => handleSaveTranslation(translation.id)}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill={translation.isSaved ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                </svg>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-zinc-900 dark:text-white">{translation.sourceText}</p>
            </div>
            <div>
              <p className="text-zinc-900 dark:text-white">{translation.translatedText}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
