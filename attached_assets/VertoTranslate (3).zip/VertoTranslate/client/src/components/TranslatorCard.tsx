import { useEffect, useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from '@/contexts/TranslationContext';
import LanguageSelector from './LanguageSelector';
import AudioControls from './AudioControls';
import { copyToClipboard } from '@/lib/utils';
import { useQuery } from '@tanstack/react-query';
import { Language } from '@shared/schema';

export default function TranslatorCard() {
  const { toast } = useToast();
  const {
    sourceLanguage,
    targetLanguage,
    sourceText,
    translatedText,
    isTranslating,
    error,
    setSourceText,
    setSourceLanguage,
    setTargetLanguage,
    swapLanguages,
    translate,
    detectLanguage,
    resetTranslation,
    setTranslatedText
  } = useTranslation();

  const [isSourceSelectorOpen, setIsSourceSelectorOpen] = useState(false);
  const [isTargetSelectorOpen, setIsTargetSelectorOpen] = useState(false);
  const [isAutoTranslate, setIsAutoTranslate] = useState(false);
  const [quality, setQuality] = useState('Standard');
  const [typingTimeout, setTypingTimeout] = useState<NodeJS.Timeout | null>(null);
  const [isConversationMode, setIsConversationMode] = useState(false);

  // Fetch languages
  const { data: languages = [] } = useQuery<Language[]>({
    queryKey: ['/api/languages'],
  });

  // Get language details for display
  const getLanguageDetails = (code: string) => {
    return languages.find(lang => lang.code === code) || { 
      code, 
      name: code.toUpperCase(),
      nativeName: code.toUpperCase(),
      flag: '🌐'
    };
  };

  const sourceLanguageDetails = getLanguageDetails(sourceLanguage);
  const targetLanguageDetails = getLanguageDetails(targetLanguage);

  // Handle auto-translate
  useEffect(() => {
    if (isAutoTranslate && sourceText.trim()) {
      if (typingTimeout) {
        clearTimeout(typingTimeout);
      }
      
      const timeout = setTimeout(() => {
        translate();
      }, 1000);
      
      setTypingTimeout(timeout);
    }
    
    return () => {
      if (typingTimeout) {
        clearTimeout(typingTimeout);
      }
    };
  }, [sourceText, isAutoTranslate, translate]);

  // Handle language detection
  const handleDetectLanguage = async () => {
    if (!sourceText.trim()) {
      toast({
        title: "Error",
        description: "Please enter text to detect language",
        variant: "destructive"
      });
      return;
    }
    
    try {
      await detectLanguage();
      toast({
        title: "Language detected",
        description: `Detected language: ${getLanguageDetails(sourceLanguage).name}`
      });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to detect language",
        variant: "destructive"
      });
    }
  };

  // Handle copy text
  const handleCopySource = async () => {
    try {
      await copyToClipboard(sourceText);
      toast({
        title: "Copied!",
        description: "Source text copied to clipboard"
      });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy text",
        variant: "destructive"
      });
    }
  };

  const handleCopyTranslation = async () => {
    try {
      await copyToClipboard(translatedText);
      toast({
        title: "Copied!",
        description: "Translation copied to clipboard"
      });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy text",
        variant: "destructive"
      });
    }
  };

  // Handle clear input text
  const handleClearText = () => {
    setSourceText('');
  };
  
  // Handle clear translated text
  const handleClearTranslatedText = () => {
    setTranslatedText('');
  };
  
  // Handle clear both
  const handleClearBoth = () => {
    resetTranslation();
  };

  // Handle reply in conversation mode
  const handleConversationReply = () => {
    // Move the translated text to the source field for a reply
    setSourceText(translatedText);
    setTranslatedText('');
    // Swap languages for the reply
    swapLanguages();
    toast({
      title: "Conversation Mode",
      description: "Languages swapped for reply"
    });
  };

  return (
    <div className="bg-white dark:bg-zinc-900 rounded-xl shadow-md border border-zinc-200 dark:border-zinc-800 mb-8">
      <div className="p-4 md:p-6">
        {/* Language Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {/* Source Language */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300">
                Translate from
              </label>
              <button 
                className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center"
                onClick={handleDetectLanguage}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
                Detect language
              </button>
            </div>

            <div className="relative">
              <button 
                className="w-full flex items-center justify-between rounded-md border border-zinc-300 dark:border-zinc-700 shadow-sm px-4 py-2 bg-white dark:bg-zinc-800 text-left text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                onClick={() => setIsSourceSelectorOpen(!isSourceSelectorOpen)}
              >
                <div className="flex items-center">
                  <span className="inline-block mr-2 text-lg">{sourceLanguageDetails.flag}</span>
                  <span className="text-base font-medium">{sourceLanguageDetails.name}</span>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-zinc-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {isSourceSelectorOpen && (
                <LanguageSelector 
                  languages={languages}
                  selectedLanguage={sourceLanguage}
                  onSelect={(code) => {
                    setSourceLanguage(code);
                    setIsSourceSelectorOpen(false);
                  }}
                  onClose={() => setIsSourceSelectorOpen(false)}
                />
              )}
            </div>
          </div>

          {/* Target Language */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300">
                Translate to
              </label>
              <button 
                className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center"
                onClick={() => setIsTargetSelectorOpen(!isTargetSelectorOpen)}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                </svg>
                Browse all
              </button>
            </div>

            <div className="relative">
              <button 
                className="w-full flex items-center justify-between rounded-md border border-zinc-300 dark:border-zinc-700 shadow-sm px-4 py-2 bg-white dark:bg-zinc-800 text-left text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                onClick={() => setIsTargetSelectorOpen(!isTargetSelectorOpen)}
              >
                <div className="flex items-center">
                  <span className="inline-block mr-2 text-lg">{targetLanguageDetails.flag}</span>
                  <span className="text-base font-medium">{targetLanguageDetails.name}</span>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-zinc-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {isTargetSelectorOpen && (
                <LanguageSelector 
                  languages={languages}
                  selectedLanguage={targetLanguage}
                  onSelect={(code) => {
                    setTargetLanguage(code);
                    setIsTargetSelectorOpen(false);
                  }}
                  onClose={() => setIsTargetSelectorOpen(false)}
                />
              )}
            </div>
          </div>
        </div>

        {/* Swap Languages Button */}
        <div className="flex justify-center -mt-4 mb-4">
          <button 
            className="bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-full p-2 shadow-sm hover:bg-zinc-50 dark:hover:bg-zinc-700 transition-colors"
            onClick={swapLanguages}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-zinc-600 dark:text-zinc-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
            </svg>
          </button>
        </div>

        {/* Translation Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Source Text */}
          <div>
            <div className="relative">
              <textarea 
                className="w-full h-40 rounded-md border border-zinc-300 dark:border-zinc-700 shadow-sm px-4 py-3 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white placeholder-zinc-500 dark:placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500" 
                placeholder="Enter text to translate..."
                value={sourceText}
                onChange={(e) => setSourceText(e.target.value)}
              />
              <div className="absolute bottom-2 right-2 flex space-x-2">
                <button 
                  className="p-1.5 text-zinc-500 dark:text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition-colors" 
                  title="Clear text"
                  onClick={handleClearText}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
                <button 
                  className="p-1.5 text-zinc-500 dark:text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition-colors" 
                  title="Copy text"
                  onClick={handleCopySource}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                </button>
                <AudioControls text={sourceText} language={sourceLanguage} type="input" />
              </div>
            </div>
          </div>

          {/* Target Text */}
          <div>
            <div className="relative">
              <textarea 
                className="w-full h-40 rounded-md border border-zinc-300 dark:border-zinc-700 shadow-sm px-4 py-3 bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-white placeholder-zinc-500 dark:placeholder-zinc-400 focus:outline-none" 
                placeholder="Translation will appear here..."
                value={translatedText}
                readOnly
              />
              <div className="absolute bottom-2 right-2 flex space-x-2">
                <button 
                  className="p-1.5 text-zinc-500 dark:text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition-colors" 
                  title="Clear translation"
                  onClick={handleClearTranslatedText}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
                <button 
                  className="p-1.5 text-zinc-500 dark:text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition-colors" 
                  title="Copy translation"
                  onClick={handleCopyTranslation}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                </button>
                <button 
                  className="p-1.5 text-zinc-500 dark:text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition-colors" 
                  title="Save translation"
                  onClick={() => {
                    toast({
                      title: "Saved",
                      description: "Translation saved to favorites"
                    });
                  }}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                  </svg>
                </button>
                {isConversationMode && translatedText && (
                  <button 
                    className="p-1.5 text-zinc-500 dark:text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition-colors" 
                    title="Reply in conversation"
                    onClick={handleConversationReply}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" />
                    </svg>
                  </button>
                )}
                <AudioControls text={translatedText} language={targetLanguage} type="output" />
              </div>
            </div>
          </div>
        </div>

        {/* Error message if any */}
        {error && (
          <div className="mt-2 text-sm text-red-500">
            {error}
          </div>
        )}
        
        {/* Conversation mode helper */}
        {isConversationMode && !error && (
          <div className="mt-2 text-sm text-primary-600 dark:text-primary-400">
            <p className="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Conversation Mode is active. After translating, use the reply button to continue the conversation.
            </p>
          </div>
        )}

        {/* Translation Controls */}
        <div className="flex flex-wrap justify-between mt-4 items-center">
          <div className="flex flex-wrap gap-2">
            <button 
              className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors ${isTranslating ? 'opacity-75 cursor-not-allowed' : ''}`}
              onClick={translate}
              disabled={isTranslating}
            >
              {isTranslating ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Translating...
                </>
              ) : (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  Translate
                </>
              )}
            </button>
            <button 
              className={`inline-flex items-center px-4 py-2 border ${isAutoTranslate ? 'border-primary-300 dark:border-primary-700 bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-400' : 'border-zinc-300 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 bg-white dark:bg-zinc-800'} text-sm font-medium rounded-md hover:bg-zinc-50 dark:hover:bg-zinc-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors`}
              onClick={() => setIsAutoTranslate(!isAutoTranslate)}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              Auto-translate
            </button>
            <button 
              className={`inline-flex items-center px-4 py-2 border ${isConversationMode ? 'border-primary-300 dark:border-primary-700 bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-400' : 'border-zinc-300 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 bg-white dark:bg-zinc-800'} text-sm font-medium rounded-md hover:bg-zinc-50 dark:hover:bg-zinc-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors`}
              onClick={() => setIsConversationMode(!isConversationMode)}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
              </svg>
              Conversation Mode
            </button>
          </div>

          <div className="flex space-x-2 items-center mt-4 md:mt-0">
            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mr-2">
              Quality:
            </label>
            <div className="relative inline-block w-24 md:w-32">
              <select 
                className="block w-full pl-3 pr-10 py-2 text-sm border-zinc-300 dark:border-zinc-700 focus:outline-none focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white rounded-md"
                value={quality}
                onChange={(e) => setQuality(e.target.value)}
              >
                <option>Standard</option>
                <option>High</option>
                <option>Premium</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-zinc-700 dark:text-zinc-300">
                <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
