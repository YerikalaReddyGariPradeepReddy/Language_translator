import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from '@/contexts/TranslationContext';
import { 
  textToSpeech, 
  startSpeechRecognition, 
  stopSpeechRecognition,
  onSpeechRecognitionResult
} from '@/lib/audioUtils';
import { Loader2 } from 'lucide-react';

interface AudioControlsProps {
  text: string;
  language: string;
  type: 'input' | 'output';
}

export default function AudioControls({ text, language, type }: AudioControlsProps) {
  const { toast } = useToast();
  const { setSourceText } = useTranslation();
  const [isPlaying, setIsPlaying] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [transcription, setTranscription] = useState('');

  // Set up speech recognition result handler
  useEffect(() => {
    onSpeechRecognitionResult((text) => {
      setTranscription(text);
      if (type === 'input') {
        setSourceText(text);
      }
    });
  }, [type, setSourceText]);

  const handleTextToSpeech = async () => {
    if (!text.trim()) {
      toast({
        title: "Error",
        description: "No text to speak",
        variant: "destructive"
      });
      return;
    }

    try {
      setIsPlaying(true);
      await textToSpeech(text, language);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to play audio",
        variant: "destructive"
      });
      console.error('TTS error:', error);
    } finally {
      setIsPlaying(false);
    }
  };

  const handleStartRecording = async () => {
    try {
      setIsRecording(true);
      setTranscription('');
      await startSpeechRecognition(language);
      
      toast({
        title: "Voice Input Active",
        description: "Speak now. Recording will automatically stop after you finish speaking."
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to start voice input. Make sure your microphone is connected and permissions are granted.",
        variant: "destructive"
      });
      console.error('Speech recognition error:', error);
      setIsRecording(false);
    }
  };

  const handleStopRecording = async () => {
    try {
      await stopSpeechRecognition();
      
      // If we got a transcription, update the UI to show it was successful
      if (transcription) {
        toast({
          title: "Voice Input Completed",
          description: "Your speech has been transcribed successfully."
        });
      }
    } catch (error) {
      console.error('Speech recognition stop error:', error);
    } finally {
      setIsRecording(false);
    }
  };

  if (type === 'input') {
    return (
      <button
        className="p-1.5 text-zinc-500 dark:text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition-colors"
        title={isRecording ? "Stop recording" : "Voice input"}
        onClick={isRecording ? handleStopRecording : handleStartRecording}
        disabled={isPlaying}
      >
        {isRecording ? (
          <div className="animate-pulse">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" />
            </svg>
          </div>
        ) : (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
          </svg>
        )}
      </button>
    );
  }

  return (
    <button
      className="p-1.5 text-zinc-500 dark:text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition-colors"
      title="Listen"
      onClick={handleTextToSpeech}
      disabled={isPlaying || isRecording}
    >
      {isPlaying ? (
        <Loader2 className="h-5 w-5 animate-spin" />
      ) : (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15.536a5 5 0 017.072 0m-9.9-2.828a9 9 0 0112.728 0" />
        </svg>
      )}
    </button>
  );
}
