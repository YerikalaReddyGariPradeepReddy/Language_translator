import { useState, useRef, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Language } from '@shared/schema';

interface LanguageSelectorProps {
  languages: Language[];
  selectedLanguage: string;
  onSelect: (code: string) => void;
  onClose: () => void;
}

export default function LanguageSelector({ 
  languages, 
  selectedLanguage, 
  onSelect, 
  onClose 
}: LanguageSelectorProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const ref = useRef<HTMLDivElement>(null);

  // Filter languages based on search term
  const filteredLanguages = languages.filter(lang => {
    const searchLower = searchTerm.toLowerCase();
    return (
      lang.name.toLowerCase().includes(searchLower) ||
      lang.nativeName.toLowerCase().includes(searchLower) ||
      lang.code.toLowerCase().includes(searchLower)
    );
  });

  // Handle click outside to close
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (ref.current && !ref.current.contains(event.target as Node)) {
        onClose();
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [onClose]);

  return (
    <div 
      ref={ref}
      className="absolute z-50 top-full left-0 right-0 mt-1 rounded-md border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 shadow-lg"
    >
      <div className="p-2">
        <Input
          type="text"
          placeholder="Search languages..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="mb-2"
          autoFocus
        />
      </div>
      
      <ScrollArea className="h-64">
        <div className="p-2">
          {filteredLanguages.length === 0 ? (
            <div className="py-4 text-center text-zinc-500 dark:text-zinc-400">
              No languages found
            </div>
          ) : (
            filteredLanguages.map(language => (
              <button
                key={language.code}
                className={`w-full flex items-center px-3 py-2.5 text-left rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-700 transition-colors ${
                  language.code === selectedLanguage ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-400' : 'text-zinc-900 dark:text-white'
                }`}
                onClick={() => onSelect(language.code)}
              >
                <span className="text-lg mr-3">{language.flag}</span>
                <div>
                  <span className="font-medium">{language.name}</span>
                  <span className="text-xs text-zinc-500 dark:text-zinc-400 ml-2">
                    {language.nativeName}
                  </span>
                </div>
              </button>
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
