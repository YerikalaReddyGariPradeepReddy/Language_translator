import TranslatorCard from "@/components/TranslatorCard";
import FeaturesSection from "@/components/FeaturesSection";
import RecentTranslationsSection from "@/components/RecentTranslationsSection";
import OfflineLanguagesSection from "@/components/OfflineLanguagesSection";

export default function TranslatePage() {
  return (
    <div className="container mx-auto px-4 pt-8 pb-16 md:pt-10 md:pb-20 max-w-6xl">
      {/* Hero Section */}
      <div className="text-center mb-8 md:mb-12">
        <h1 className="font-heading text-3xl md:text-4xl font-bold text-zinc-900 dark:text-white mb-4">
          Translate text in real-time
        </h1>
        <p className="text-lg text-zinc-600 dark:text-zinc-400 max-w-3xl mx-auto">
          Accurate translations between 100+ languages with advanced AI technology
        </p>
      </div>

      {/* Translator Card */}
      <TranslatorCard />

      {/* Features Section */}
      <FeaturesSection />

      {/* Recent Translations Section */}
      <RecentTranslationsSection />

      {/* Offline Languages Section */}
      <OfflineLanguagesSection />
    </div>
  );
}
