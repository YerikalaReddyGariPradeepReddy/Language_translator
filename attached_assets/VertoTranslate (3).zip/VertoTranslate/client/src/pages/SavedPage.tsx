import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
import { Translation } from '@shared/schema';
import { formatDate, copyToClipboard, downloadTextFile } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from '@/contexts/TranslationContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Loader2, Search, Trash2, Copy, Download, Volume2, BookmarkMinus } from 'lucide-react';
import { textToSpeech } from '@/lib/audioUtils';

export default function SavedPage() {
  const { toast } = useToast();
  const { unsaveTranslation } = useTranslation();
  const [searchTerm, setSearchTerm] = useState('');
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedTranslationId, setSelectedTranslationId] = useState<number | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState<number | null>(null);

  // Fetch saved translations
  const { data: translations = [], isLoading } = useQuery<Translation[]>({
    queryKey: ['/api/translations/saved'],
  });

  // Remove from saved mutation
  const unsaveTranslationMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('POST', `/api/translations/${id}/unsave`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/translations/saved'] });
      toast({
        title: "Success",
        description: "Removed from saved translations",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update saved status",
        variant: "destructive"
      });
    }
  });

  // Delete translation mutation
  const deleteTranslationMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/translations/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/translations/saved'] });
      toast({
        title: "Success",
        description: "Translation deleted",
      });
      setIsDeleteDialogOpen(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete translation",
        variant: "destructive"
      });
    }
  });

  // Filter translations based on search term
  const filteredTranslations = translations.filter(translation => {
    const searchLower = searchTerm.toLowerCase();
    return (
      translation.sourceText.toLowerCase().includes(searchLower) ||
      translation.translatedText.toLowerCase().includes(searchLower) ||
      translation.sourceLanguage.toLowerCase().includes(searchLower) ||
      translation.targetLanguage.toLowerCase().includes(searchLower)
    );
  });

  // Handle copy text
  const handleCopyText = async (text: string) => {
    try {
      await copyToClipboard(text);
      toast({
        title: "Copied!",
        description: "Text copied to clipboard"
      });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy text",
        variant: "destructive"
      });
    }
  };

  // Handle download text
  const handleDownloadText = (translation: Translation) => {
    const text = `Original (${translation.sourceLanguage}): ${translation.sourceText}\nTranslation (${translation.targetLanguage}): ${translation.translatedText}`;
    const filename = `translation_${translation.sourceLanguage}_to_${translation.targetLanguage}_${Date.now()}.txt`;
    downloadTextFile(text, filename);
    toast({
      title: "Success",
      description: "Translation downloaded as text file"
    });
  };

  // Handle unsave translation
  const handleUnsave = async (id: number) => {
    try {
      await unsaveTranslation(id);
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to remove from saved",
        variant: "destructive"
      });
    }
  };

  // Handle delete translation
  const handleDeleteClick = (id: number) => {
    setSelectedTranslationId(id);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (selectedTranslationId !== null) {
      deleteTranslationMutation.mutate(selectedTranslationId);
    }
  };

  // Handle text-to-speech
  const handleTextToSpeech = async (text: string, language: string, id: number) => {
    try {
      setIsPlayingAudio(id);
      await textToSpeech(text, language);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to play audio",
        variant: "destructive"
      });
    } finally {
      setIsPlayingAudio(null);
    }
  };

  return (
    <div className="container mx-auto px-4 pt-8 pb-16 md:pt-10 md:pb-20 max-w-6xl">
      <div className="mb-8">
        <h1 className="font-heading text-3xl md:text-4xl font-bold text-zinc-900 dark:text-white mb-4">
          Saved Translations
        </h1>
        <p className="text-lg text-zinc-600 dark:text-zinc-400">
          Your collection of saved translations for quick access
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500 dark:text-zinc-400" />
          <Input
            type="text"
            placeholder="Search saved translations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
        <Button variant="outline" onClick={() => setSearchTerm('')} disabled={!searchTerm}>
          Clear
        </Button>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center p-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary-500 mb-4" />
          <p className="text-zinc-600 dark:text-zinc-400">Loading saved translations...</p>
        </div>
      ) : filteredTranslations.length === 0 ? (
        <Card className="p-12 text-center">
          <div className="w-16 h-16 bg-zinc-100 dark:bg-zinc-800 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-zinc-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
            </svg>
          </div>
          {searchTerm ? (
            <>
              <h3 className="text-xl font-semibold mb-2 text-zinc-900 dark:text-white">No matching saved translations</h3>
              <p className="text-zinc-600 dark:text-zinc-400 mb-4">
                Try adjusting your search criteria or clear the search filter
              </p>
              <Button onClick={() => setSearchTerm('')}>Clear Search</Button>
            </>
          ) : (
            <>
              <h3 className="text-xl font-semibold mb-2 text-zinc-900 dark:text-white">No saved translations yet</h3>
              <p className="text-zinc-600 dark:text-zinc-400 mb-4">
                Save your most useful or important translations for quick access anytime
              </p>
              <Button className="px-6" onClick={() => window.location.href = '/'}>Start Translating</Button>
            </>
          )}
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredTranslations.map((translation) => (
            <div key={translation.id} className="bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 p-4">
              <div className="flex flex-wrap items-center justify-between mb-3 gap-2">
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium text-zinc-500 dark:text-zinc-400">
                    {translation.sourceLanguage.toUpperCase()} → {translation.targetLanguage.toUpperCase()}
                  </span>
                  <span className="text-xs px-2 py-0.5 bg-zinc-100 dark:bg-zinc-800 rounded-full text-zinc-600 dark:text-zinc-400">
                    {formatDate(translation.createdAt)}
                  </span>
                </div>
                <div className="flex space-x-2">
                  <button
                    className={`p-1.5 rounded-full ${
                      isPlayingAudio === translation.id 
                        ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400' 
                        : 'text-zinc-400 dark:text-zinc-500 hover:text-zinc-600 dark:hover:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                    }`}
                    onClick={() => handleTextToSpeech(translation.translatedText, translation.targetLanguage, translation.id)}
                    disabled={isPlayingAudio !== null}
                  >
                    {isPlayingAudio === translation.id ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Volume2 className="h-4 w-4" />
                    )}
                  </button>
                  <button
                    className="p-1.5 rounded-full text-zinc-400 dark:text-zinc-500 hover:text-zinc-600 dark:hover:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                    onClick={() => handleCopyText(`${translation.sourceText}\n${translation.translatedText}`)}
                  >
                    <Copy className="h-4 w-4" />
                  </button>
                  <button
                    className="p-1.5 rounded-full text-zinc-400 dark:text-zinc-500 hover:text-zinc-600 dark:hover:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                    onClick={() => handleDownloadText(translation)}
                  >
                    <Download className="h-4 w-4" />
                  </button>
                  <button
                    className="p-1.5 rounded-full text-zinc-400 dark:text-zinc-500 hover:text-primary-600 dark:hover:text-primary-400 hover:bg-primary-50 dark:hover:bg-primary-900/20"
                    onClick={() => handleUnsave(translation.id)}
                  >
                    <BookmarkMinus className="h-4 w-4" />
                  </button>
                  <button
                    className="p-1.5 rounded-full text-zinc-400 dark:text-zinc-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20"
                    onClick={() => handleDeleteClick(translation.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-zinc-50 dark:bg-zinc-800/50 rounded-md p-3">
                  <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400 mb-1">Original ({translation.sourceLanguage})</p>
                  <p className="text-zinc-900 dark:text-white">{translation.sourceText}</p>
                </div>
                <div className="bg-zinc-50 dark:bg-zinc-800/50 rounded-md p-3">
                  <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400 mb-1">Translation ({translation.targetLanguage})</p>
                  <p className="text-zinc-900 dark:text-white">{translation.translatedText}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Translation</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this translation? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              {deleteTranslationMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
