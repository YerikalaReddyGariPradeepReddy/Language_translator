import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
import { Language, OfflineLanguage } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from '@/components/ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Loader2, 
  Search, 
  Download, 
  Trash2, 
  CheckCircle2, 
  HardDrive, 
  Wifi, 
  WifiOff, 
  Globe 
} from 'lucide-react';

export default function DownloadsPage() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLanguageId, setSelectedLanguageId] = useState<number | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDownloading, setIsDownloading] = useState<number | null>(null);
  const [downloadProgress, setDownloadProgress] = useState(0);

  // Fetch all languages
  const { data: allLanguages = [], isLoading: isLoadingLanguages } = useQuery<Language[]>({
    queryKey: ['/api/languages'],
  });

  // Fetch offline languages
  const { 
    data: offlineLanguages = [], 
    isLoading: isLoadingOffline 
  } = useQuery<(OfflineLanguage & { language: Language })[]>({
    queryKey: ['/api/offline-languages'],
  });

  // Download language mutation
  const downloadLanguageMutation = useMutation({
    mutationFn: async (languageId: number) => {
      setIsDownloading(languageId);
      
      // Simulate download progress
      for (let i = 0; i <= 100; i += 10) {
        setDownloadProgress(i);
        await new Promise(resolve => setTimeout(resolve, 300));
      }
      
      const response = await apiRequest('POST', '/api/offline-languages', { languageId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/offline-languages'] });
      toast({
        title: "Success",
        description: "Language downloaded for offline use",
      });
      setIsDownloading(null);
      setDownloadProgress(0);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to download language",
        variant: "destructive"
      });
      setIsDownloading(null);
      setDownloadProgress(0);
    }
  });

  // Remove offline language mutation
  const removeLanguageMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/offline-languages/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/offline-languages'] });
      toast({
        title: "Success",
        description: "Language removed from offline storage",
      });
      setIsDeleteDialogOpen(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to remove language",
        variant: "destructive"
      });
    }
  });

  // Filter languages based on search term
  const filteredAllLanguages = allLanguages.filter(language => {
    const searchLower = searchTerm.toLowerCase();
    return (
      language.name.toLowerCase().includes(searchLower) ||
      language.nativeName.toLowerCase().includes(searchLower) ||
      language.code.toLowerCase().includes(searchLower)
    );
  });

  const filteredOfflineLanguages = offlineLanguages.filter(item => {
    const searchLower = searchTerm.toLowerCase();
    return (
      item.language.name.toLowerCase().includes(searchLower) ||
      item.language.nativeName.toLowerCase().includes(searchLower) ||
      item.language.code.toLowerCase().includes(searchLower)
    );
  });

  // Get available languages (those not already downloaded)
  const availableLanguages = filteredAllLanguages.filter(
    language => !offlineLanguages.some(ol => ol.language.id === language.id)
  );

  // Handle download language
  const handleDownloadLanguage = (languageId: number) => {
    downloadLanguageMutation.mutate(languageId);
  };

  // Handle delete language
  const handleDeleteLanguage = (id: number) => {
    setSelectedLanguageId(id);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (selectedLanguageId !== null) {
      removeLanguageMutation.mutate(selectedLanguageId);
    }
  };

  // Calculate total offline storage used
  const totalStorageUsed = offlineLanguages.reduce(
    (total, item) => total + (item.language.sizeInMb || 0), 
    0
  );

  return (
    <div className="container mx-auto px-4 pt-8 pb-16 md:pt-10 md:pb-20 max-w-6xl">
      <div className="mb-8">
        <h1 className="font-heading text-3xl md:text-4xl font-bold text-zinc-900 dark:text-white mb-4">
          Offline Languages
        </h1>
        <p className="text-lg text-zinc-600 dark:text-zinc-400">
          Download languages for offline translation when you're without internet
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center">
              <HardDrive className="h-5 w-5 mr-2" />
              Storage Used
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-zinc-900 dark:text-white">
              {totalStorageUsed} MB
            </div>
            <Progress 
              value={Math.min((totalStorageUsed / 1000) * 100, 100)}
              className="h-2 mt-2"
            />
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-2">
              {offlineLanguages.length} languages downloaded
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center">
              <WifiOff className="h-5 w-5 mr-2" />
              Offline Mode
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-lg text-zinc-900 dark:text-white">
              <span className="font-medium">Available</span>
              <span className="ml-2 inline-flex h-6 w-6 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
              </span>
            </div>
            <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">
              You can translate offline with your downloaded languages
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center">
              <Globe className="h-5 w-5 mr-2" />
              Available Languages
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-zinc-900 dark:text-white">
              {allLanguages.length}
            </div>
            <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">
              Languages available for download
            </p>
          </CardContent>
          <CardFooter className="pt-0">
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full"
              onClick={() => document.getElementById('available-languages')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Browse Languages
            </Button>
          </CardFooter>
        </Card>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500 dark:text-zinc-400" />
          <Input
            type="text"
            placeholder="Search languages..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
        <Button variant="outline" onClick={() => setSearchTerm('')} disabled={!searchTerm}>
          Clear
        </Button>
      </div>

      <Tabs defaultValue="downloaded" className="mb-6">
        <TabsList className="mb-4">
          <TabsTrigger value="downloaded" className="flex items-center">
            <CheckCircle2 className="h-4 w-4 mr-2" />
            Downloaded
          </TabsTrigger>
          <TabsTrigger value="available" className="flex items-center" id="available-languages">
            <Download className="h-4 w-4 mr-2" />
            Available
          </TabsTrigger>
        </TabsList>

        <TabsContent value="downloaded">
          {isLoadingOffline ? (
            <div className="flex flex-col items-center justify-center p-12 bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-800">
              <Loader2 className="h-8 w-8 animate-spin text-primary-500 mb-4" />
              <p className="text-zinc-600 dark:text-zinc-400">Loading downloaded languages...</p>
            </div>
          ) : filteredOfflineLanguages.length === 0 ? (
            <div className="text-center py-12 bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-800">
              <div className="w-16 h-16 bg-zinc-100 dark:bg-zinc-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <WifiOff className="h-8 w-8 text-zinc-400" />
              </div>
              {searchTerm ? (
                <>
                  <h3 className="text-xl font-semibold mb-2 text-zinc-900 dark:text-white">No matching downloaded languages</h3>
                  <p className="text-zinc-600 dark:text-zinc-400 mb-4 max-w-md mx-auto">
                    Try adjusting your search term or download more languages
                  </p>
                  <Button variant="outline" onClick={() => setSearchTerm('')}>
                    Clear Search
                  </Button>
                </>
              ) : (
                <>
                  <h3 className="text-xl font-semibold mb-2 text-zinc-900 dark:text-white">No languages downloaded yet</h3>
                  <p className="text-zinc-600 dark:text-zinc-400 mb-4 max-w-md mx-auto">
                    Download languages to use offline when you don't have an internet connection
                  </p>
                  <Button onClick={() => document.getElementById('available-languages')?.click()}>
                    Browse Available Languages
                  </Button>
                </>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {filteredOfflineLanguages.map(item => (
                <div 
                  key={item.id}
                  className="bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-800 p-4"
                >
                  <div className="flex items-center mb-3">
                    <span className="text-2xl mr-3">{item.language.flag}</span>
                    <div>
                      <h3 className="font-medium text-zinc-900 dark:text-white">{item.language.name}</h3>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400">
                        {item.language.nativeName} • {item.language.sizeInMb} MB
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="inline-flex items-center text-xs text-green-600 dark:text-green-400">
                      <CheckCircle2 className="h-3.5 w-3.5 mr-1" />
                      Downloaded
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
                      onClick={() => handleDeleteLanguage(item.id)}
                      disabled={removeLanguageMutation.isPending && selectedLanguageId === item.id}
                    >
                      {removeLanguageMutation.isPending && selectedLanguageId === item.id ? (
                        <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                      ) : (
                        <Trash2 className="h-4 w-4 mr-1" />
                      )}
                      Remove
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="available">
          {isLoadingLanguages ? (
            <div className="flex flex-col items-center justify-center p-12 bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-800">
              <Loader2 className="h-8 w-8 animate-spin text-primary-500 mb-4" />
              <p className="text-zinc-600 dark:text-zinc-400">Loading available languages...</p>
            </div>
          ) : availableLanguages.length === 0 ? (
            <div className="text-center py-12 bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-800">
              <div className="w-16 h-16 bg-zinc-100 dark:bg-zinc-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="h-8 w-8 text-green-500" />
              </div>
              {searchTerm ? (
                <>
                  <h3 className="text-xl font-semibold mb-2 text-zinc-900 dark:text-white">No matching available languages</h3>
                  <p className="text-zinc-600 dark:text-zinc-400 mb-4 max-w-md mx-auto">
                    Try adjusting your search term
                  </p>
                  <Button variant="outline" onClick={() => setSearchTerm('')}>
                    Clear Search
                  </Button>
                </>
              ) : (
                <>
                  <h3 className="text-xl font-semibold mb-2 text-zinc-900 dark:text-white">All languages downloaded!</h3>
                  <p className="text-zinc-600 dark:text-zinc-400 mb-4 max-w-md mx-auto">
                    You have already downloaded all available languages
                  </p>
                  <Button onClick={() => document.getElementById('downloaded-tab')?.click()}>
                    View Downloaded Languages
                  </Button>
                </>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {availableLanguages.map(language => (
                <div 
                  key={language.id}
                  className="bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-800 p-4"
                >
                  <div className="flex items-center mb-3">
                    <span className="text-2xl mr-3">{language.flag}</span>
                    <div>
                      <h3 className="font-medium text-zinc-900 dark:text-white">{language.name}</h3>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400">
                        {language.nativeName} • {language.sizeInMb} MB
                      </p>
                    </div>
                  </div>
                  {isDownloading === language.id ? (
                    <div className="space-y-2">
                      <Progress value={downloadProgress} className="h-2" />
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-zinc-500 dark:text-zinc-400">Downloading...</span>
                        <span className="text-zinc-700 dark:text-zinc-300">{downloadProgress}%</span>
                      </div>
                    </div>
                  ) : (
                    <Button 
                      size="sm" 
                      className="w-full"
                      onClick={() => handleDownloadLanguage(language.id)}
                      disabled={!!isDownloading}
                    >
                      <Download className="h-4 w-4 mr-1.5" />
                      Download
                    </Button>
                  )}
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Offline Translation Tips</CardTitle>
          <CardDescription>
            Make the most of your offline translation experience
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex">
            <div className="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center shrink-0 mr-3">
              <Wifi className="h-5 w-5 text-primary-600 dark:text-primary-400" />
            </div>
            <div>
              <h3 className="font-medium text-zinc-900 dark:text-white mb-1">Download Over Wi-Fi</h3>
              <p className="text-sm text-zinc-600 dark:text-zinc-400">
                Language packs can be large. Download them while connected to Wi-Fi to save mobile data.
              </p>
            </div>
          </div>
          
          <div className="flex">
            <div className="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center shrink-0 mr-3">
              <HardDrive className="h-5 w-5 text-primary-600 dark:text-primary-400" />
            </div>
            <div>
              <h3 className="font-medium text-zinc-900 dark:text-white mb-1">Manage Storage</h3>
              <p className="text-sm text-zinc-600 dark:text-zinc-400">
                Remove languages you don't need anymore to free up storage space on your device.
              </p>
            </div>
          </div>
          
          <div className="flex">
            <div className="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center shrink-0 mr-3">
              <WifiOff className="h-5 w-5 text-primary-600 dark:text-primary-400" />
            </div>
            <div>
              <h3 className="font-medium text-zinc-900 dark:text-white mb-1">Offline Mode Limitations</h3>
              <p className="text-sm text-zinc-600 dark:text-zinc-400">
                Some advanced features like voice input might be limited when using offline translation.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Offline Language</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove this language from offline storage? You'll need an internet connection to use it again.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              {removeLanguageMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Removing...
                </>
              ) : (
                "Remove"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
