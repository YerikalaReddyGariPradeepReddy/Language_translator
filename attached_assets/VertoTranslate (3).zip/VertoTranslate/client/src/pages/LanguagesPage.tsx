import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Language } from '@shared/schema';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2 } from 'lucide-react';

export default function LanguagesPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentTab, setCurrentTab] = useState('all');

  // Fetch languages
  const { data: languages = [], isLoading } = useQuery<Language[]>({
    queryKey: ['/api/languages'],
  });

  // Group languages by region
  const regions = {
    europe: ['en', 'fr', 'es', 'de', 'it', 'pt', 'nl', 'pl', 'sv', 'da', 'fi', 'no', 'cs', 'hu', 'ro', 'bg', 'el'],
    asia: ['zh', 'ja', 'ko', 'hi', 'th', 'vi', 'id', 'ms', 'tl', 'ur'],
    middleEast: ['ar', 'he', 'fa', 'tr'],
    africa: ['sw', 'am', 'ha', 'yo', 'zu'],
    americas: ['pt-br', 'es-mx', 'es-ar', 'es-co', 'fr-ca'],
  };

  // Filter languages based on search term
  const filteredLanguages = languages.filter(lang => {
    const searchLower = searchTerm.toLowerCase();
    return (
      lang.name.toLowerCase().includes(searchLower) ||
      lang.nativeName.toLowerCase().includes(searchLower) ||
      lang.code.toLowerCase().includes(searchLower)
    );
  });

  // Filter by tab/region
  const getLanguagesByRegion = (regionCodes: string[]) => {
    return filteredLanguages.filter(lang => regionCodes.includes(lang.code));
  };

  const displayLanguages = currentTab === 'all' 
    ? filteredLanguages 
    : getLanguagesByRegion(regions[currentTab as keyof typeof regions]);

  return (
    <div className="container mx-auto px-4 pt-8 pb-16 md:pt-10 md:pb-20 max-w-6xl">
      <div className="mb-8">
        <h1 className="font-heading text-3xl md:text-4xl font-bold text-zinc-900 dark:text-white mb-4">
          Languages
        </h1>
        <p className="text-lg text-zinc-600 dark:text-zinc-400">
          Browse and explore the 100+ languages supported by Verto translator
        </p>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Supported Languages</CardTitle>
          <CardDescription>
            Verto supports translation between any combination of the following languages
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <Input
              type="text"
              placeholder="Search languages..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-md"
            />
          </div>

          <Tabs defaultValue="all" value={currentTab} onValueChange={setCurrentTab}>
            <div className="overflow-auto pb-2">
              <TabsList>
                <TabsTrigger value="all">All Languages</TabsTrigger>
                <TabsTrigger value="europe">Europe</TabsTrigger>
                <TabsTrigger value="asia">Asia</TabsTrigger>
                <TabsTrigger value="middleEast">Middle East</TabsTrigger>
                <TabsTrigger value="africa">Africa</TabsTrigger>
                <TabsTrigger value="americas">Americas</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value={currentTab} className="mt-4">
              {isLoading ? (
                <div className="flex items-center justify-center py-10">
                  <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
                </div>
              ) : displayLanguages.length === 0 ? (
                <div className="text-center py-10 bg-zinc-50 dark:bg-zinc-800/50 rounded-lg">
                  <p className="text-zinc-600 dark:text-zinc-400">No languages found matching your search</p>
                </div>
              ) : (
                <ScrollArea className={`h-[500px] pr-4`}>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    {displayLanguages.map(language => (
                      <div 
                        key={language.code}
                        className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg p-4 hover:border-primary-300 dark:hover:border-primary-700 transition-colors"
                      >
                        <div className="flex items-center">
                          <span className="text-3xl mr-3">{language.flag}</span>
                          <div>
                            <h3 className="font-medium text-zinc-900 dark:text-white">{language.name}</h3>
                            <p className="text-sm text-zinc-500 dark:text-zinc-400">
                              {language.nativeName}
                              <span className="text-xs ml-2 text-zinc-400 dark:text-zinc-500">
                                {language.code}
                              </span>
                            </p>
                          </div>
                        </div>
                        {language.isOfflineAvailable && (
                          <div className="mt-2 flex items-center text-xs text-primary-600 dark:text-primary-400">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                            </svg>
                            Available offline
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Language Features</CardTitle>
          <CardDescription>
            Enhance your translation experience with these language capabilities
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex">
              <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center shrink-0 mr-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-600 dark:text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2 text-zinc-900 dark:text-white">Automatic Detection</h3>
                <p className="text-zinc-600 dark:text-zinc-400">
                  Our AI-powered system can detect the language of your input text automatically, making translation easier than ever.
                </p>
              </div>
            </div>

            <div className="flex">
              <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center shrink-0 mr-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-600 dark:text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2 text-zinc-900 dark:text-white">Pronunciation</h3>
                <p className="text-zinc-600 dark:text-zinc-400">
                  Hear the correct pronunciation for any text in its native language with our high-quality text-to-speech functionality.
                </p>
              </div>
            </div>

            <div className="flex">
              <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center shrink-0 mr-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-600 dark:text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2 text-zinc-900 dark:text-white">Offline Use</h3>
                <p className="text-zinc-600 dark:text-zinc-400">
                  Download languages for offline translation when traveling without reliable internet access.
                </p>
              </div>
            </div>

            <div className="flex">
              <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center shrink-0 mr-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-600 dark:text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2 text-zinc-900 dark:text-white">Context Awareness</h3>
                <p className="text-zinc-600 dark:text-zinc-400">
                  Our translation engine understands context and cultural nuances to provide more accurate and natural-sounding translations.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
