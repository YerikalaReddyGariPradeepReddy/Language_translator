import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { copyToClipboard } from '@/lib/utils';
import { Language } from '@shared/schema';
import LanguageSelector from '@/components/LanguageSelector';
import { 
  textToSpeech, 
  startSpeechRecognition, 
  stopSpeechRecognition,
  onSpeechRecognitionResult
} from '@/lib/audioUtils';

interface ConversationMessage {
  id: string;
  text: string;
  translation: string;
  speaker: 'person1' | 'person2';
  language: string;
  timestamp: Date;
}

export default function ConversationPage() {
  const { toast } = useToast();

  const [person1Language, setPerson1Language] = useState('en');
  const [person2Language, setPerson2Language] = useState('es');
  const [currentSpeaker, setCurrentSpeaker] = useState<'person1' | 'person2'>('person1');
  const [isListening, setIsListening] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [conversation, setConversation] = useState<ConversationMessage[]>([]);
  const [currentInput, setCurrentInput] = useState('');
  const [isTranslating, setIsTranslating] = useState(false);
  const [isPerson1SelectorOpen, setIsPerson1SelectorOpen] = useState(false);
  const [isPerson2SelectorOpen, setIsPerson2SelectorOpen] = useState(false);
  const [autoTranslate, setAutoTranslate] = useState(true);

  // Fetch languages
  const { data: languages = [] } = useQuery<Language[]>({
    queryKey: ['/api/languages'],
  });

  // Get language details for display
  const getLanguageDetails = (code: string) => {
    return languages.find(lang => lang.code === code) || { 
      code, 
      name: code.toUpperCase(),
      nativeName: code.toUpperCase(),
      flag: '🌐'
    };
  };

  const person1LanguageDetails = getLanguageDetails(person1Language);
  const person2LanguageDetails = getLanguageDetails(person2Language);

  // Set up speech recognition
  useEffect(() => {
    onSpeechRecognitionResult((text) => {
      setCurrentInput(text);
      
      if (autoTranslate && text.trim()) {
        handleTranslateAndAdd(text);
      }
    });
  }, [autoTranslate, currentSpeaker, person1Language, person2Language]);

  const handleTranslateAndAdd = async (textToTranslate: string) => {
    const sourceLanguage = currentSpeaker === 'person1' ? person1Language : person2Language;
    const targetLanguage = currentSpeaker === 'person1' ? person2Language : person1Language;

    setIsTranslating(true);

    try {
      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: textToTranslate,
          sourceLanguage,
          targetLanguage
        })
      });
      
      const result = await response.json();
      let translatedText = '';
      
      if (result.translatedText) {
        translatedText = result.translatedText;
      } else if (result.translation?.translatedText) {
        translatedText = result.translation.translatedText;
      }

      if (translatedText) {
        const newMessage: ConversationMessage = {
          id: Date.now().toString(),
          text: textToTranslate,
          translation: translatedText,
          speaker: currentSpeaker,
          language: sourceLanguage,
          timestamp: new Date()
        };

        setConversation(prev => [...prev, newMessage]);
        setCurrentInput('');

        // Auto-play translation if enabled
        if (autoTranslate) {
          setTimeout(() => {
            textToSpeech(translatedText, targetLanguage).catch(console.error);
          }, 500);
        }

        toast({
          title: "Message Added",
          description: `Message from ${currentSpeaker === 'person1' ? 'Person 1' : 'Person 2'} translated successfully`
        });
      }
    } catch (err) {
      toast({
        title: "Translation Error",
        description: "Failed to translate message",
        variant: "destructive"
      });
    } finally {
      setIsTranslating(false);
    }
  };

  const handleStartListening = async () => {
    const sourceLanguage = currentSpeaker === 'person1' ? person1Language : person2Language;
    const speakerName = currentSpeaker === 'person1' ? 'Person 1' : 'Person 2';

    try {
      setIsListening(true);
      setCurrentInput('');
      
      await startSpeechRecognition(sourceLanguage);
      
      toast({
        title: "Voice Input Active",
        description: `${speakerName} can speak now in ${getLanguageDetails(sourceLanguage).name}`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to start voice recognition. Check microphone permissions.",
        variant: "destructive"
      });
      setIsListening(false);
    }
  };

  const handleStopListening = async () => {
    try {
      await stopSpeechRecognition();
      setIsListening(false);
      
      if (currentInput && autoTranslate) {
        // Translation will be handled by the useEffect
      }
    } catch (error) {
      console.error('Error stopping speech recognition:', error);
      setIsListening(false);
    }
  };

  const handlePlayMessage = async (text: string, language: string) => {
    try {
      setIsPlaying(true);
      await textToSpeech(text, language);
    } catch (error) {
      toast({
        title: "Playback Error",
        description: "Failed to play message",
        variant: "destructive"
      });
    } finally {
      setIsPlaying(false);
    }
  };

  const handleCopyMessage = async (text: string) => {
    try {
      await copyToClipboard(text);
      toast({
        title: "Copied!",
        description: "Message copied to clipboard"
      });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy message",
        variant: "destructive"
      });
    }
  };

  const handleClearConversation = () => {
    setConversation([]);
    setCurrentInput('');
    toast({
      title: "Conversation Cleared",
      description: "All messages have been removed"
    });
  };

  const switchSpeaker = () => {
    setCurrentSpeaker(prev => prev === 'person1' ? 'person2' : 'person1');
    if (isListening) {
      handleStopListening();
    }
  };

  const swapLanguages = () => {
    const temp = person1Language;
    setPerson1Language(person2Language);
    setPerson2Language(temp);
    
    toast({
      title: "Languages Swapped",
      description: "Person 1 and Person 2 languages have been switched"
    });
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-zinc-900 dark:text-white mb-2">
          Conversation Mode
        </h1>
        <p className="text-zinc-600 dark:text-zinc-400">
          Enable two people to have natural conversations in different languages
        </p>
      </div>

      {/* Language Setup */}
      <div className="bg-white dark:bg-zinc-900 rounded-xl shadow-md border border-zinc-200 dark:border-zinc-800 p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-zinc-900 dark:text-white">Conversation Setup</h2>
          <button
            onClick={swapLanguages}
            className="px-3 py-1 text-sm bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 rounded-md hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors"
          >
            Swap Languages
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Person 1 */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <h3 className="font-medium text-zinc-900 dark:text-white">Person 1</h3>
            </div>
            <div className="relative">
              <button 
                className="w-full flex items-center justify-between rounded-md border border-zinc-300 dark:border-zinc-700 shadow-sm px-4 py-3 bg-white dark:bg-zinc-800 text-left text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                onClick={() => setIsPerson1SelectorOpen(!isPerson1SelectorOpen)}
              >
                <div className="flex items-center">
                  <span className="inline-block mr-3 text-xl">{person1LanguageDetails.flag}</span>
                  <span className="text-base font-medium">{person1LanguageDetails.name}</span>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-zinc-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {isPerson1SelectorOpen && (
                <LanguageSelector 
                  languages={languages}
                  selectedLanguage={person1Language}
                  onSelect={(code) => {
                    setPerson1Language(code);
                    setIsPerson1SelectorOpen(false);
                  }}
                  onClose={() => setIsPerson1SelectorOpen(false)}
                />
              )}
            </div>
          </div>

          {/* Person 2 */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <h3 className="font-medium text-zinc-900 dark:text-white">Person 2</h3>
            </div>
            <div className="relative">
              <button 
                className="w-full flex items-center justify-between rounded-md border border-zinc-300 dark:border-zinc-700 shadow-sm px-4 py-3 bg-white dark:bg-zinc-800 text-left text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                onClick={() => setIsPerson2SelectorOpen(!isPerson2SelectorOpen)}
              >
                <div className="flex items-center">
                  <span className="inline-block mr-3 text-xl">{person2LanguageDetails.flag}</span>
                  <span className="text-base font-medium">{person2LanguageDetails.name}</span>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-zinc-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {isPerson2SelectorOpen && (
                <LanguageSelector 
                  languages={languages}
                  selectedLanguage={person2Language}
                  onSelect={(code) => {
                    setPerson2Language(code);
                    setIsPerson2SelectorOpen(false);
                  }}
                  onClose={() => setIsPerson2SelectorOpen(false)}
                />
              )}
            </div>
          </div>
        </div>

        {/* Settings */}
        <div className="mt-4 flex flex-wrap gap-4 items-center">
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="autoTranslateConvo"
              checked={autoTranslate}
              onChange={(e) => setAutoTranslate(e.target.checked)}
              className="rounded border-zinc-300 text-primary-600 focus:ring-primary-500"
            />
            <label htmlFor="autoTranslateConvo" className="text-sm text-zinc-700 dark:text-zinc-300">
              Auto-translate and speak
            </label>
          </div>
        </div>
      </div>

      {/* Voice Input Control */}
      <div className="bg-white dark:bg-zinc-900 rounded-xl shadow-md border border-zinc-200 dark:border-zinc-800 p-6">
        <div className="text-center">
          <div className="mb-4">
            <div className="flex justify-center items-center space-x-4 mb-4">
              <button
                onClick={() => setCurrentSpeaker('person1')}
                className={`px-4 py-2 rounded-md transition-colors ${
                  currentSpeaker === 'person1' 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700'
                }`}
              >
                Person 1
              </button>
              <button
                onClick={switchSpeaker}
                className="p-2 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors"
                title="Switch speaker"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                </svg>
              </button>
              <button
                onClick={() => setCurrentSpeaker('person2')}
                className={`px-4 py-2 rounded-md transition-colors ${
                  currentSpeaker === 'person2' 
                    ? 'bg-green-500 text-white' 
                    : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700'
                }`}
              >
                Person 2
              </button>
            </div>
          </div>

          <button
            onClick={isListening ? handleStopListening : handleStartListening}
            disabled={isTranslating}
            className={`inline-flex items-center justify-center w-20 h-20 rounded-full text-white text-xl transition-all duration-200 ${
              isListening 
                ? 'bg-red-500 hover:bg-red-600 animate-pulse' 
                : currentSpeaker === 'person1' 
                  ? 'bg-blue-500 hover:bg-blue-600'
                  : 'bg-green-500 hover:bg-green-600'
            } ${isTranslating ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {isListening ? (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
            )}
          </button>

          <p className="mt-3 text-sm text-zinc-600 dark:text-zinc-400">
            {isListening 
              ? `${currentSpeaker === 'person1' ? 'Person 1' : 'Person 2'} is speaking...` 
              : `Click for ${currentSpeaker === 'person1' ? 'Person 1' : 'Person 2'} to speak`
            }
          </p>

          {/* Current Input Display */}
          {currentInput && (
            <div className="mt-4 p-3 bg-zinc-50 dark:bg-zinc-800 rounded-lg">
              <p className="text-zinc-900 dark:text-white">{currentInput}</p>
              {!autoTranslate && (
                <button
                  onClick={() => handleTranslateAndAdd(currentInput)}
                  disabled={isTranslating}
                  className="mt-2 px-3 py-1 bg-primary-600 text-white text-sm rounded-md hover:bg-primary-700 disabled:opacity-50"
                >
                  {isTranslating ? 'Adding...' : 'Add to Conversation'}
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Conversation History */}
      <div className="bg-white dark:bg-zinc-900 rounded-xl shadow-md border border-zinc-200 dark:border-zinc-800 p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-zinc-900 dark:text-white">Conversation</h2>
          {conversation.length > 0 && (
            <button
              onClick={handleClearConversation}
              className="px-3 py-1 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-md transition-colors"
            >
              Clear All
            </button>
          )}
        </div>

        {conversation.length === 0 ? (
          <div className="text-center py-8 text-zinc-500 dark:text-zinc-400">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto mb-3 opacity-50" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
            </svg>
            <p>No messages yet. Start speaking to begin the conversation!</p>
          </div>
        ) : (
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {conversation.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.speaker === 'person1' ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                    message.speaker === 'person1'
                      ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-900 dark:text-blue-100'
                      : 'bg-green-100 dark:bg-green-900/30 text-green-900 dark:text-green-100'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium opacity-75">
                      {message.speaker === 'person1' ? 'Person 1' : 'Person 2'}
                    </span>
                    <div className="flex space-x-1">
                      <button
                        onClick={() => handleCopyMessage(message.text)}
                        className="p-1 opacity-60 hover:opacity-100 transition-opacity"
                        title="Copy original"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                      </button>
                      <button
                        onClick={() => handlePlayMessage(message.text, message.language)}
                        disabled={isPlaying}
                        className="p-1 opacity-60 hover:opacity-100 transition-opacity disabled:opacity-30"
                        title="Play original"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15.536a5 5 0 017.072 0m-9.9-2.828a9 9 0 0112.728 0" />
                        </svg>
                      </button>
                    </div>
                  </div>
                  <p className="text-sm mb-2">{message.text}</p>
                  <div className="border-t border-current opacity-30 my-2"></div>
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">{message.translation}</p>
                    <div className="flex space-x-1 ml-2">
                      <button
                        onClick={() => handleCopyMessage(message.translation)}
                        className="p-1 opacity-60 hover:opacity-100 transition-opacity"
                        title="Copy translation"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                      </button>
                      <button
                        onClick={() => handlePlayMessage(message.translation, message.speaker === 'person1' ? person2Language : person1Language)}
                        disabled={isPlaying}
                        className="p-1 opacity-60 hover:opacity-100 transition-opacity disabled:opacity-30"
                        title="Play translation"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15.536a5 5 0 017.072 0m-9.9-2.828a9 9 0 0112.728 0" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}