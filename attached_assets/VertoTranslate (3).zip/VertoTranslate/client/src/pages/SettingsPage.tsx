import { useState, useEffect } from 'react';
import { useTheme } from '@/contexts/ThemeContext';
import { useToast } from '@/hooks/use-toast';
import { downloadTextFile } from '@/lib/utils';
import { useQuery } from '@tanstack/react-query';
import { Translation } from '@shared/schema';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter,
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Palette, 
  Volume2, 
  Moon, 
  Sun, 
  Monitor, 
  Download,
  FileDown,
  RotateCcw,
  Languages,
  Globe,
  Speaker
} from 'lucide-react';

export default function SettingsPage() {
  const { theme, setTheme, toggleTheme } = useTheme();
  const { toast } = useToast();
  
  // Settings state
  const [autoDetect, setAutoDetect] = useState(true);
  const [autoTranslate, setAutoTranslate] = useState(false);
  const [translationQuality, setTranslationQuality] = useState('standard');
  const [speakingRate, setSpeakingRate] = useState([1]);
  const [speechVoice, setSpeechVoice] = useState('default');
  const [showPhonetics, setShowPhonetics] = useState(false);
  const [suggestCorrections, setSuggestCorrections] = useState(true);
  const [saveHistory, setSaveHistory] = useState(true);
  
  // Get all translations for export
  const { data: translations = [] } = useQuery<Translation[]>({
    queryKey: ['/api/translations'],
    enabled: false, // Only fetch when needed
    staleTime: Infinity
  });
  
  // Get system theme preference
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    
    const handleChange = (e: MediaQueryListEvent) => {
      if (theme === 'system') {
        setTheme(e.matches ? 'dark' : 'light');
      }
    };
    
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [theme, setTheme]);
  
  // Handle export translations
  const handleExportTranslations = async () => {
    try {
      const exportData = translations.map(t => ({
        id: t.id,
        sourceText: t.sourceText,
        translatedText: t.translatedText,
        sourceLanguage: t.sourceLanguage,
        targetLanguage: t.targetLanguage,
        createdAt: t.createdAt,
        isSaved: t.isSaved
      }));
      
      const jsonString = JSON.stringify(exportData, null, 2);
      const filename = `verto_translations_${new Date().toISOString().slice(0, 10)}.json`;
      
      downloadTextFile(jsonString, filename);
      
      toast({
        title: "Export Successful",
        description: `Exported ${translations.length} translations to ${filename}`
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export translations",
        variant: "destructive"
      });
    }
  };
  
  // Handle reset settings
  const handleResetSettings = () => {
    setAutoDetect(true);
    setAutoTranslate(false);
    setTranslationQuality('standard');
    setSpeakingRate([1]);
    setSpeechVoice('default');
    setShowPhonetics(false);
    setSuggestCorrections(true);
    setSaveHistory(true);
    setTheme('system');
    
    toast({
      title: "Settings Reset",
      description: "All settings have been reset to default values"
    });
  };

  return (
    <div className="container mx-auto px-4 pt-8 pb-16 md:pt-10 md:pb-20 max-w-6xl">
      <div className="mb-8">
        <h1 className="font-heading text-3xl md:text-4xl font-bold text-zinc-900 dark:text-white mb-4">
          Settings
        </h1>
        <p className="text-lg text-zinc-600 dark:text-zinc-400">
          Customize your translation experience
        </p>
      </div>

      <Tabs defaultValue="appearance" className="mb-8">
        <TabsList className="mb-6">
          <TabsTrigger value="appearance" className="flex items-center">
            <Palette className="h-4 w-4 mr-2" />
            Appearance
          </TabsTrigger>
          <TabsTrigger value="translation" className="flex items-center">
            <Languages className="h-4 w-4 mr-2" />
            Translation
          </TabsTrigger>
          <TabsTrigger value="audio" className="flex items-center">
            <Speaker className="h-4 w-4 mr-2" />
            Audio
          </TabsTrigger>
          <TabsTrigger value="data" className="flex items-center">
            <Globe className="h-4 w-4 mr-2" />
            Data & Privacy
          </TabsTrigger>
        </TabsList>

        <TabsContent value="appearance">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Theme Settings</CardTitle>
              <CardDescription>
                Customize the appearance of the application
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <Label>Color Theme</Label>
                <RadioGroup 
                  value={theme} 
                  onValueChange={(value) => setTheme(value as 'light' | 'dark' | 'system')}
                  className="flex flex-col sm:flex-row gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="light" id="light" />
                    <Label htmlFor="light" className="flex items-center cursor-pointer">
                      <Sun className="h-4 w-4 mr-2" />
                      Light
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="dark" id="dark" />
                    <Label htmlFor="dark" className="flex items-center cursor-pointer">
                      <Moon className="h-4 w-4 mr-2" />
                      Dark
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="system" id="system" />
                    <Label htmlFor="system" className="flex items-center cursor-pointer">
                      <Monitor className="h-4 w-4 mr-2" />
                      System
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Quick Theme Toggle</Label>
                  <p className="text-sm text-zinc-500 dark:text-zinc-400">
                    Switch between light and dark mode
                  </p>
                </div>
                <Button onClick={toggleTheme} variant="outline" size="sm">
                  {theme === 'dark' ? (
                    <>
                      <Sun className="h-4 w-4 mr-2" />
                      Switch to Light
                    </>
                  ) : (
                    <>
                      <Moon className="h-4 w-4 mr-2" />
                      Switch to Dark
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="translation">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Translation Preferences</CardTitle>
              <CardDescription>
                Configure how translations are processed
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="auto-detect">Auto Detect Language</Label>
                  <p className="text-sm text-zinc-500 dark:text-zinc-400">
                    Automatically detect the language of your input text
                  </p>
                </div>
                <Switch 
                  id="auto-detect" 
                  checked={autoDetect}
                  onCheckedChange={setAutoDetect}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="auto-translate">Auto Translate</Label>
                  <p className="text-sm text-zinc-500 dark:text-zinc-400">
                    Translate text automatically as you type
                  </p>
                </div>
                <Switch 
                  id="auto-translate" 
                  checked={autoTranslate}
                  onCheckedChange={setAutoTranslate}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="translation-quality">Translation Quality</Label>
                <Select 
                  value={translationQuality} 
                  onValueChange={setTranslationQuality}
                >
                  <SelectTrigger id="translation-quality">
                    <SelectValue placeholder="Select quality" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="premium">Premium</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-zinc-500 dark:text-zinc-400">
                  Higher quality translations may take longer to process
                </p>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="show-phonetics">Show Phonetics</Label>
                  <p className="text-sm text-zinc-500 dark:text-zinc-400">
                    Display phonetic transcriptions for non-Latin languages
                  </p>
                </div>
                <Switch 
                  id="show-phonetics" 
                  checked={showPhonetics}
                  onCheckedChange={setShowPhonetics}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="suggest-corrections">Suggest Corrections</Label>
                  <p className="text-sm text-zinc-500 dark:text-zinc-400">
                    Get suggestions for improving your original text
                  </p>
                </div>
                <Switch 
                  id="suggest-corrections" 
                  checked={suggestCorrections}
                  onCheckedChange={setSuggestCorrections}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="audio">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Audio Settings</CardTitle>
              <CardDescription>
                Customize text-to-speech and voice recognition
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Speaking Rate</Label>
                  <span className="text-sm text-zinc-700 dark:text-zinc-300">
                    {speakingRate[0]}x
                  </span>
                </div>
                <Slider
                  value={speakingRate}
                  onValueChange={setSpeakingRate}
                  min={0.5}
                  max={2}
                  step={0.1}
                />
                <p className="text-sm text-zinc-500 dark:text-zinc-400">
                  Adjust the speed of text-to-speech playback
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="speech-voice">Voice Selection</Label>
                <Select 
                  value={speechVoice} 
                  onValueChange={setSpeechVoice}
                >
                  <SelectTrigger id="speech-voice">
                    <SelectValue placeholder="Select voice" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default">Default</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="male">Male</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-zinc-500 dark:text-zinc-400">
                  Choose a voice type for text-to-speech playback
                </p>
              </div>

              <div className="pt-2">
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => {
                    const testText = "This is a test of the text-to-speech system";
                    const utterance = new SpeechSynthesisUtterance(testText);
                    utterance.rate = speakingRate[0];
                    window.speechSynthesis.speak(utterance);
                  }}
                >
                  <Volume2 className="h-4 w-4 mr-2" />
                  Test Audio
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="data">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Data & Privacy</CardTitle>
              <CardDescription>
                Manage your data and privacy settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="save-history">Save Translation History</Label>
                  <p className="text-sm text-zinc-500 dark:text-zinc-400">
                    Store your translation history for future reference
                  </p>
                </div>
                <Switch 
                  id="save-history" 
                  checked={saveHistory}
                  onCheckedChange={setSaveHistory}
                />
              </div>

              <div className="border-t border-zinc-200 dark:border-zinc-800 pt-6">
                <h3 className="text-sm font-medium text-zinc-900 dark:text-white mb-2">Export Data</h3>
                <p className="text-sm text-zinc-500 dark:text-zinc-400 mb-4">
                  Download a copy of your translation history
                </p>
                <Button 
                  variant="outline" 
                  onClick={handleExportTranslations}
                  className="flex items-center"
                >
                  <FileDown className="h-4 w-4 mr-2" />
                  Export Translations
                </Button>
              </div>

              <div className="border-t border-zinc-200 dark:border-zinc-800 pt-6">
                <h3 className="text-sm font-medium text-zinc-900 dark:text-white mb-2">Clear Data</h3>
                <p className="text-sm text-zinc-500 dark:text-zinc-400 mb-4">
                  Permanently delete your saved translations
                </p>
                <Button 
                  variant="destructive" 
                  onClick={() => {
                    toast({
                      title: "Feature Not Available",
                      description: "This feature is not implemented in the demo",
                    });
                  }}
                >
                  Clear Translation History
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Application Settings</CardTitle>
          <CardDescription>
            Manage general application settings
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium text-zinc-900 dark:text-white">Version</h3>
                <p className="text-sm text-zinc-500 dark:text-zinc-400">
                  Verto Translator v1.0.0
                </p>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  toast({
                    title: "Up to Date",
                    description: "You're using the latest version",
                  });
                }}
              >
                Check for Updates
              </Button>
            </div>

            <div className="border-t border-zinc-200 dark:border-zinc-800 pt-6">
              <h3 className="text-sm font-medium text-zinc-900 dark:text-white mb-2">Offline Languages</h3>
              <p className="text-sm text-zinc-500 dark:text-zinc-400 mb-4">
                Manage languages for offline use
              </p>
              <Button 
                variant="outline"
                onClick={() => window.location.href = '/downloads'}
              >
                <Download className="h-4 w-4 mr-2" />
                Manage Downloads
              </Button>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col sm:flex-row gap-4 sm:justify-between">
          <Button 
            variant="outline" 
            onClick={handleResetSettings}
            className="w-full sm:w-auto"
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            Reset to Defaults
          </Button>
          <Button 
            className="w-full sm:w-auto"
            onClick={() => {
              toast({
                title: "Settings Saved",
                description: "Your settings have been saved successfully",
              });
            }}
          >
            Save Settings
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
