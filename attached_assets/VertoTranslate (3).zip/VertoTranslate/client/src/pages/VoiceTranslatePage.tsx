import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from '@/contexts/TranslationContext';
import { copyToClipboard } from '@/lib/utils';
import { Language } from '@shared/schema';
import LanguageSelector from '@/components/LanguageSelector';
import { 
  textToSpeech, 
  startSpeechRecognition, 
  stopSpeechRecognition,
  onSpeechRecognitionResult
} from '@/lib/audioUtils';

export default function VoiceTranslatePage() {
  const { toast } = useToast();
  const {
    sourceLanguage,
    targetLanguage,
    setSourceLanguage,
    setTargetLanguage,
    translate,
    isTranslating,
    error
  } = useTranslation();

  const [isListening, setIsListening] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [voiceText, setVoiceText] = useState('');
  const [translatedVoiceText, setTranslatedVoiceText] = useState('');
  const [isSourceSelectorOpen, setIsSourceSelectorOpen] = useState(false);
  const [isTargetSelectorOpen, setIsTargetSelectorOpen] = useState(false);
  const [voiceQuality, setVoiceQuality] = useState('high');
  const [autoTranslate, setAutoTranslate] = useState(true);
  const [confidenceScore, setConfidenceScore] = useState(0);

  // Fetch languages
  const { data: languages = [] } = useQuery<Language[]>({
    queryKey: ['/api/languages'],
  });

  // Get language details for display
  const getLanguageDetails = (code: string) => {
    return languages.find(lang => lang.code === code) || { 
      code, 
      name: code.toUpperCase(),
      nativeName: code.toUpperCase(),
      flag: '🌐'
    };
  };

  const sourceLanguageDetails = getLanguageDetails(sourceLanguage);
  const targetLanguageDetails = getLanguageDetails(targetLanguage);

  // Set up enhanced speech recognition
  useEffect(() => {
    onSpeechRecognitionResult((text, confidence = 0) => {
      setVoiceText(text);
      setConfidenceScore(confidence);
      
      if (autoTranslate && text.trim()) {
        handleVoiceTranslate(text);
      }
    });
  }, [autoTranslate, sourceLanguage, targetLanguage]);

  const handleVoiceTranslate = async (textToTranslate: string) => {
    try {
      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: textToTranslate,
          sourceLanguage,
          targetLanguage
        })
      });
      
      const result = await response.json();
      if (result.translatedText) {
        setTranslatedVoiceText(result.translatedText);
      } else if (result.translation?.translatedText) {
        setTranslatedVoiceText(result.translation.translatedText);
      }
    } catch (err) {
      toast({
        title: "Translation Error",
        description: "Failed to translate voice input",
        variant: "destructive"
      });
    }
  };

  const handleStartListening = async () => {
    try {
      setIsListening(true);
      setVoiceText('');
      setTranslatedVoiceText('');
      setConfidenceScore(0);
      
      await startSpeechRecognition(sourceLanguage);
      
      toast({
        title: "Voice Recognition Active",
        description: `Listening in ${sourceLanguageDetails.name}. Speak now...`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to start voice recognition. Check microphone permissions.",
        variant: "destructive"
      });
      setIsListening(false);
    }
  };

  const handleStopListening = async () => {
    try {
      await stopSpeechRecognition();
      setIsListening(false);
      
      if (voiceText) {
        toast({
          title: "Voice Input Complete",
          description: "Speech recognition finished successfully."
        });
      }
    } catch (error) {
      console.error('Error stopping speech recognition:', error);
      setIsListening(false);
    }
  };

  const handlePlayTranslation = async () => {
    if (!translatedVoiceText.trim()) {
      toast({
        title: "No Translation",
        description: "No translated text to play",
        variant: "destructive"
      });
      return;
    }

    try {
      setIsPlaying(true);
      await textToSpeech(translatedVoiceText, targetLanguage);
    } catch (error) {
      toast({
        title: "Playback Error",
        description: "Failed to play translation",
        variant: "destructive"
      });
    } finally {
      setIsPlaying(false);
    }
  };

  const handleCopyText = async (text: string, type: string) => {
    try {
      await copyToClipboard(text);
      toast({
        title: "Copied!",
        description: `${type} copied to clipboard`
      });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy text",
        variant: "destructive"
      });
    }
  };

  const handleClearAll = () => {
    setVoiceText('');
    setTranslatedVoiceText('');
    setConfidenceScore(0);
  };

  const getConfidenceColor = () => {
    if (confidenceScore >= 0.8) return 'text-green-600 dark:text-green-400';
    if (confidenceScore >= 0.6) return 'text-yellow-600 dark:text-yellow-400';
    return 'text-red-600 dark:text-red-400';
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-zinc-900 dark:text-white mb-2">
          Voice Translation
        </h1>
        <p className="text-zinc-600 dark:text-zinc-400">
          Speak naturally and get instant translations with enhanced voice recognition
        </p>
      </div>

      {/* Language Selection */}
      <div className="bg-white dark:bg-zinc-900 rounded-xl shadow-md border border-zinc-200 dark:border-zinc-800 p-6">
        <h2 className="text-xl font-semibold mb-4 text-zinc-900 dark:text-white">Language Settings</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          {/* Source Language */}
          <div>
            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">
              Speak in
            </label>
            <div className="relative">
              <button 
                className="w-full flex items-center justify-between rounded-md border border-zinc-300 dark:border-zinc-700 shadow-sm px-4 py-3 bg-white dark:bg-zinc-800 text-left text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                onClick={() => setIsSourceSelectorOpen(!isSourceSelectorOpen)}
              >
                <div className="flex items-center">
                  <span className="inline-block mr-3 text-xl">{sourceLanguageDetails.flag}</span>
                  <span className="text-base font-medium">{sourceLanguageDetails.name}</span>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-zinc-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {isSourceSelectorOpen && (
                <LanguageSelector 
                  languages={languages}
                  selectedLanguage={sourceLanguage}
                  onSelect={(code) => {
                    setSourceLanguage(code);
                    setIsSourceSelectorOpen(false);
                  }}
                  onClose={() => setIsSourceSelectorOpen(false)}
                />
              )}
            </div>
          </div>

          {/* Target Language */}
          <div>
            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">
              Translate to
            </label>
            <div className="relative">
              <button 
                className="w-full flex items-center justify-between rounded-md border border-zinc-300 dark:border-zinc-700 shadow-sm px-4 py-3 bg-white dark:bg-zinc-800 text-left text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                onClick={() => setIsTargetSelectorOpen(!isTargetSelectorOpen)}
              >
                <div className="flex items-center">
                  <span className="inline-block mr-3 text-xl">{targetLanguageDetails.flag}</span>
                  <span className="text-base font-medium">{targetLanguageDetails.name}</span>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-zinc-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {isTargetSelectorOpen && (
                <LanguageSelector 
                  languages={languages}
                  selectedLanguage={targetLanguage}
                  onSelect={(code) => {
                    setTargetLanguage(code);
                    setIsTargetSelectorOpen(false);
                  }}
                  onClose={() => setIsTargetSelectorOpen(false)}
                />
              )}
            </div>
          </div>
        </div>

        {/* Voice Settings */}
        <div className="flex flex-wrap gap-4 items-center">
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="autoTranslate"
              checked={autoTranslate}
              onChange={(e) => setAutoTranslate(e.target.checked)}
              className="rounded border-zinc-300 text-primary-600 focus:ring-primary-500"
            />
            <label htmlFor="autoTranslate" className="text-sm text-zinc-700 dark:text-zinc-300">
              Auto-translate speech
            </label>
          </div>

          <div className="flex items-center space-x-2">
            <label className="text-sm text-zinc-700 dark:text-zinc-300">Voice Quality:</label>
            <select 
              value={voiceQuality}
              onChange={(e) => setVoiceQuality(e.target.value)}
              className="text-sm border border-zinc-300 dark:border-zinc-700 rounded px-2 py-1 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white"
            >
              <option value="standard">Standard</option>
              <option value="high">High</option>
              <option value="premium">Premium</option>
            </select>
          </div>
        </div>
      </div>

      {/* Voice Input Section */}
      <div className="bg-white dark:bg-zinc-900 rounded-xl shadow-md border border-zinc-200 dark:border-zinc-800 p-6">
        <h2 className="text-xl font-semibold mb-4 text-zinc-900 dark:text-white">Voice Input</h2>
        
        {/* Microphone Control */}
        <div className="text-center mb-6">
          <button
            onClick={isListening ? handleStopListening : handleStartListening}
            disabled={isTranslating}
            className={`inline-flex items-center justify-center w-24 h-24 rounded-full text-white text-2xl transition-all duration-200 ${
              isListening 
                ? 'bg-red-500 hover:bg-red-600 animate-pulse' 
                : 'bg-primary-600 hover:bg-primary-700'
            } ${isTranslating ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {isListening ? (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
            )}
          </button>
          <p className="mt-3 text-sm text-zinc-600 dark:text-zinc-400">
            {isListening ? 'Listening... Click to stop' : 'Click to start voice input'}
          </p>
        </div>

        {/* Voice Input Display */}
        {voiceText && (
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-lg font-medium text-zinc-900 dark:text-white">Recognized Speech</h3>
              <div className="flex items-center space-x-2">
                {confidenceScore > 0 && (
                  <span className={`text-xs font-medium ${getConfidenceColor()}`}>
                    {Math.round(confidenceScore * 100)}% confidence
                  </span>
                )}
                <button
                  onClick={() => handleCopyText(voiceText, 'Speech')}
                  className="p-1 text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300"
                  title="Copy speech"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                </button>
              </div>
            </div>
            <div className="bg-zinc-50 dark:bg-zinc-800 rounded-lg p-4">
              <p className="text-zinc-900 dark:text-white">{voiceText}</p>
            </div>
          </div>
        )}

        {/* Translation Display */}
        {translatedVoiceText && (
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-lg font-medium text-zinc-900 dark:text-white">Translation</h3>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleCopyText(translatedVoiceText, 'Translation')}
                  className="p-1 text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300"
                  title="Copy translation"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                </button>
                <button
                  onClick={handlePlayTranslation}
                  disabled={isPlaying}
                  className="p-1 text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300 disabled:opacity-50"
                  title="Play translation"
                >
                  {isPlaying ? (
                    <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15.536a5 5 0 017.072 0m-9.9-2.828a9 9 0 0112.728 0" />
                    </svg>
                  )}
                </button>
              </div>
            </div>
            <div className="bg-primary-50 dark:bg-primary-900/20 rounded-lg p-4">
              <p className="text-zinc-900 dark:text-white">{translatedVoiceText}</p>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex justify-center space-x-4">
          <button
            onClick={handleClearAll}
            className="px-4 py-2 border border-zinc-300 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 rounded-md hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-colors"
          >
            Clear All
          </button>
          {!autoTranslate && voiceText && (
            <button
              onClick={() => handleVoiceTranslate(voiceText)}
              disabled={isTranslating}
              className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 disabled:opacity-50 transition-colors"
            >
              {isTranslating ? 'Translating...' : 'Translate'}
            </button>
          )}
        </div>

        {/* Error Display */}
        {error && (
          <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md">
            <p className="text-red-700 dark:text-red-400 text-sm">{error}</p>
          </div>
        )}
      </div>
    </div>
  );
}