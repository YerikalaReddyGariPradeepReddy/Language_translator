import { useContext } from 'react';
import { TranslationContext } from '@/contexts/TranslationContext';

// Re-export the useTranslation hook for easier imports
export function useTranslation() {
  const context = useContext(TranslationContext);
  
  if (context === undefined) {
    throw new Error('useTranslation must be used within a TranslationProvider');
  }
  
  return context;
}

export default useTranslation;
