import { Language } from '@shared/schema';

export interface LanguageGroup {
  name: string;
  languages: string[];
}

export const languageGroups: LanguageGroup[] = [
  {
    name: 'Popular',
    languages: ['en', 'es', 'fr', 'de', 'zh', 'ja', 'ko', 'ru', 'ar', 'hi']
  },
  {
    name: 'European',
    languages: ['en', 'fr', 'es', 'de', 'it', 'pt', 'nl', 'pl', 'sv', 'da', 'fi', 'no', 'cs', 'hu', 'ro', 'bg', 'el', 'uk']
  },
  {
    name: 'Indian',
    languages: ['hi', 'te', 'ta', 'kn', 'ml', 'mr', 'bn', 'pa', 'ur', 'gu', 'or']
  },
  {
    name: 'Asian',
    languages: ['zh', 'ja', 'ko', 'th', 'vi', 'id', 'ms', 'tl']
  },
  {
    name: 'Middle Eastern',
    languages: ['ar', 'he', 'fa', 'tr', 'ur']
  },
  {
    name: 'African',
    languages: ['sw', 'am', 'ha', 'yo', 'zu']
  }
];

// Helper function to get language details
export function getLanguageDetails(languages: Language[], code: string): Language {
  const language = languages.find(lang => lang.code === code);
  if (language) return language;
  
  // Return a placeholder if not found
  return {
    id: 0,
    code,
    name: code.toUpperCase(),
    nativeName: code.toUpperCase(),
    flag: '🌐',
    isOfflineAvailable: false,
    sizeInMb: 0
  };
}

// Get popular languages
export function getPopularLanguages(languages: Language[]): Language[] {
  const popularCodes = languageGroups[0].languages;
  return languages.filter(lang => popularCodes.includes(lang.code));
}

// Group languages by region
export function getLanguagesByGroup(languages: Language[], groupName: string): Language[] {
  const group = languageGroups.find(g => g.name.toLowerCase() === groupName.toLowerCase());
  if (!group) return [];
  
  return languages.filter(lang => group.languages.includes(lang.code));
}

// Helper to format language for display
export function formatLanguageDisplay(language: Language): string {
  return `${language.flag} ${language.name} (${language.nativeName})`;
}

// Helper to check if language is RTL
export const rtlLanguages = ['ar', 'he', 'fa', 'ur'];

export function isRtlLanguage(languageCode: string): boolean {
  return rtlLanguages.includes(languageCode);
}
