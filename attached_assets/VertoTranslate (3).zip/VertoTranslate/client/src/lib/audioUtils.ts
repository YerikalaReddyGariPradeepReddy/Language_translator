// Create a type for speech recognition
interface IWindow extends Window {
  SpeechRecognition: any;
  webkitSpeechRecognition: any;
  mozSpeechRecognition: any;
  msSpeechRecognition: any;
}

// Get speech recognition constructor
const getRecognition = () => {
  const windowWithSpeech = window as unknown as IWindow;
  return windowWithSpeech.SpeechRecognition || 
         windowWithSpeech.webkitSpeechRecognition || 
         windowWithSpeech.mozSpeechRecognition || 
         windowWithSpeech.msSpeechRecognition;
};

// Store active recognition instance
let recognition: any = null;
let recognitionCallback: ((text: string) => void) | null = null;

// Text-to-speech function
export async function textToSpeech(text: string, languageCode: string): Promise<void> {
  return new Promise((resolve, reject) => {
    if (!text || !text.trim()) {
      reject(new Error('No text provided'));
      return;
    }

    try {
      // Cancel any existing speech
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = mapLanguageCode(languageCode);
      utterance.rate = 1.0;
      utterance.pitch = 1.0;

      utterance.onend = () => {
        resolve();
      };

      utterance.onerror = (event) => {
        reject(new Error(`Speech synthesis error: ${event.error}`));
      };

      window.speechSynthesis.speak(utterance);
    } catch (error) {
      reject(error);
    }
  });
}

// Start speech recognition for voice input
export async function startSpeechRecognition(languageCode: string): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      const SpeechRecognition = getRecognition();
      
      if (!SpeechRecognition) {
        reject(new Error('Speech recognition not supported in this browser'));
        return;
      }

      // Create new recognition instance
      recognition = new SpeechRecognition();
      recognition.lang = mapLanguageCode(languageCode);
      recognition.continuous = false;
      recognition.interimResults = true;
      
      recognition.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((result: any) => result[0].transcript)
          .join('');
        
        if (recognitionCallback) {
          recognitionCallback(transcript);
        }
        
        // If final result
        if (event.results[0].isFinal) {
          stopSpeechRecognition();
        }
      };
      
      recognition.onerror = (event: any) => {
        reject(new Error(`Speech recognition error: ${event.error}`));
        stopSpeechRecognition();
      };
      
      recognition.onend = () => {
        resolve();
      };
      
      recognition.start();
      resolve();
    } catch (error) {
      reject(error);
    }
  });
}

// Stop speech recognition
export async function stopSpeechRecognition(): Promise<void> {
  if (recognition) {
    try {
      recognition.stop();
    } catch (error) {
      console.error('Error stopping speech recognition:', error);
    }
    recognition = null;
  }
  return Promise.resolve();
}

// Register callback for speech recognition
export function onSpeechRecognitionResult(callback: (text: string) => void): void {
  recognitionCallback = callback;
}

// Map language codes to BCP 47 language tags used by the Web Speech API
function mapLanguageCode(code: string): string {
  // Map of language codes that need special handling
  const languageMap: Record<string, string> = {
    // Major languages
    'zh': 'zh-CN',    // Chinese (Simplified)
    'zh-TW': 'zh-TW', // Chinese (Traditional)
    'en': 'en-US',    // English (US)
    'en-GB': 'en-GB', // English (UK)
    'pt': 'pt-PT',    // Portuguese (Portugal)
    'pt-BR': 'pt-BR', // Portuguese (Brazil)
    
    // Indian languages
    'hi': 'hi-IN',    // Hindi
    'bn': 'bn-IN',    // Bengali
    'te': 'te-IN',    // Telugu
    'ta': 'ta-IN',    // Tamil
    'mr': 'mr-IN',    // Marathi
    'gu': 'gu-IN',    // Gujarati
    'kn': 'kn-IN',    // Kannada
    'ml': 'ml-IN',    // Malayalam
    'pa': 'pa-IN',    // Punjabi
    'ur': 'ur-IN',    // Urdu (India)
    
    // Other major languages
    'ar': 'ar-SA',    // Arabic
    'ja': 'ja-JP',    // Japanese
    'ko': 'ko-KR',    // Korean
    'fr': 'fr-FR',    // French
    'de': 'de-DE',    // German
    'es': 'es-ES',    // Spanish
    'it': 'it-IT',    // Italian
    'ru': 'ru-RU',    // Russian
  };
  
  return languageMap[code] || code;
}
